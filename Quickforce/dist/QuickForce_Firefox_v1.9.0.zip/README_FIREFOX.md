# QuickForce — Firefox (MV3)
Load temporarily for testing:
1) Open `about:debugging#/runtime/this-firefox`
2) Click **Load Temporary Add-on…**, select this folder's `manifest.json`

Publish:
- Zip the folder and upload it to addons.mozilla.org (AMO). The included `browser_specific_settings.gecko.id` is `quickforce@eddie`.
- Minimum Firefox version set to 109.0 (MV3 + scripting API).
